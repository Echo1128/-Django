from django.contrib import admin
from user.models import User
from django.utils import timezone
from leave.models import ApplyLeave
from certify.models import ApplyCertify
# Register your models here.

class LeaveManager(admin.ModelAdmin):
    list_display = ['flowid','apply_id','user_name']
    list_filter = ['flowid','apply_id']

admin.site.register(ApplyLeave, LeaveManager)

class CertifyManager(admin.ModelAdmin):
    list_display = ['flowid','apply_id','certify_type']
    list_filter = ['flowid','apply_id']

admin.site.register(ApplyCertify, CertifyManager)

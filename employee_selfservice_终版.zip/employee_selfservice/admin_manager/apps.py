from django.apps import AppConfig


class AdminManagerConfig(AppConfig):
    name = 'admin_manager'

from django.shortcuts import render

# Create your views here.
import hashlib
import json

from django.http import JsonResponse
from django.shortcuts import render
from user.models import User


# Create your views here.

#登录页面
def login_view(request):

    return render(request,'login.html')

#登录页面发送的数据处理
def login_post(request):
    json_str = request.body
    json_obj = json.loads(json_str)
    # 获取用户名和密码
    user_id = json_obj['user_id']
    user_name = json_obj['user_name']
    password = json_obj['password']

    if user_id == '' or user_name == '' or password == '':
        result = {'code': 10200, 'error': '工号,姓名或密码不能为空'}
        return JsonResponse(result)

    try:
        user = User.objects.get(user_id=user_id)
    except Exception as e:
        print('---login error %s' % (e))
        result = {'code': 10201, 'error': '你的工号或密码输入错误'}
        return JsonResponse(result)

    #md5加密
    h_m = hashlib.md5()
    h_m.update(password.encode())
    if h_m.hexdigest() != user.password:
        result = {'code': 10202, 'error': '你的工号或密码输入错误'}
        return JsonResponse(result)

    if user_name != user.user_name:
        result = {'code': 10203, 'error': '你的姓名输入错误'}
        return JsonResponse(result)


    result = {'code': 200, 'page': 'home','id':user_id}
    return JsonResponse(result)

#忘记密码页面函数
def forget_view(request):

    return render(request,'forget.html')

#手机号发送短信函数
def phone_view(request):

    json_str = request.body
    json_obj = json.loads(json_str)

    user_id = json_obj['user_id']
    phone = json_obj['phone']
    if not user_id or not phone:
        result = {'code': 10110, 'error': '用户工号或手机号为空'}
        return JsonResponse(result)
    try:
        user = User.objects.get(user_id=user_id)
        print(user)
        user_phone = user.phone
        print(user_phone)
    except Exception as e:
        print('---phone post error %s' % (e))
        result = {'code': 10111, 'error': '你的工号输入错误'}
        return JsonResponse(result)

    if user_phone:
        if user_phone != phone:
            result = {'code': 10112, 'error': '你的手机号输入错误'}
            return JsonResponse(result)
    #发送短信 统一发送验证码为123456

    return JsonResponse({'code':200,'con':'密码发送成功'})


#忘记密码页面提交数据处理函数
def forget_post(request):
    json_str = request.body
    json_obj = json.loads(json_str)

    user_id = json_obj['user_id']
    sms_num = json_obj['sms_num']
    password1 = json_obj['password_1']
    password2 = json_obj['password_2']
    print(user_id,sms_num,password1,password2)

    if not password1 or not password2:
        result = {'code': 10120, 'error': '用户新密码为空'}
        return JsonResponse(result)
    if password1 != password2:
        result = {'code': 10121, 'error': '用户新密码两次输入不一致'}
        return JsonResponse(result)
    if sms_num != '123456':
        result = {'code': 10122, 'error': '验证码错误'}
        return JsonResponse(result)


    h_m = hashlib.md5()
    h_m.update(password1.encode())
    password = h_m.hexdigest()

    try:
        user = User.objects.get(user_id=user_id)
    except Exception as e:
        print('---login error %s' % (e))
        result = {'code': 10223, 'error': '你的工号输入错误'}
        return JsonResponse(result)
    # 数据库密码的更改
    User.objects.filter(user_id=user_id).update(password=password)

    result = {'code': 200}
    return JsonResponse(result)




#注册页面
def reg_view(request):

    return render(request,'register.html')
#注册页面发送的数据处理
def reg_post(request):
    json_str = request.body
    json_obj = json.loads(json_str)
    # 获取用户名和密码
    user_id = json_obj['user_id']
    user_name = json_obj['user_name']
    phone = json_obj['phone']
    password = json_obj['password']
    department = json_obj['department']
    position = json_obj['position']


    if user_id == '' or user_name == '':
        result = {'code': 10101, 'error': '用户工号或姓名输入不能为空'}
        return JsonResponse(result)
    if department == '' or position == '':
        result = {'code': 10102, 'error': '用户密码,部门或岗位输入不能为空'}
        return JsonResponse(result)

    # TODO 参数检查
    if len(user_name) > 11:
        result = {'code': 10103, 'error': '用户姓名输入错误'}
        return JsonResponse(result)
    if len(phone) > 11:
        result = {'code': 10104, 'error': '用户手机号输入错误'}
        return JsonResponse(result)

    if department not in ['技术', '人事', '其它']:
        result = {'code': 10105, 'error': '用户部门输入错误'}
        return JsonResponse(result)

    old_user = User.objects.filter(user_id=user_id)
    if old_user:
        result = {'code': 10106, 'error': '用户工号或姓名输入错误'}
        return JsonResponse(result)

    #密码加密
    h_m = hashlib.md5()
    h_m.update(password.encode())
    password = h_m.hexdigest()
    print(user_id,user_name,password,department,position,phone)
    # 插入数据
    ###这里错误
    try:
        user = User.objects.create(user_id=user_id,user_name=user_name,password=password,department=department,position=position,phone=phone)
    except Exception as e:
        print('create error is %s' % (e))
        result = {'code': 10107, 'error': '用户工号或姓名输入错误'}
        return JsonResponse(result)

    result = {'code': 200, 'page': 'home','id':user_id}
    return JsonResponse(result)

#主页函数
def home_page(request):

    #取数据
    user_id = request.GET.get('user_id')
    user = User.objects.get(user_id=user_id)
    user_name = user.user_name
    department = user.department
    # 判断部门是否为人事
    if department == '人事':
        return render(request,'home_1.html',locals())
    else:
        return render(request, 'home.html',locals())


#修改密码
def change_view(request):

    return render(request,'change.html')

#修改密码数据处理
def put_view(request):
    json_str = request.body
    json_obj = json.loads(json_str)

    user_id = json_obj['user_id']
    old_password = json_obj['old_password']
    password_1 = json_obj['password_1']
    password_2 = json_obj['password_2']

    h_m = hashlib.md5()
    h_m.update(old_password.encode())
    old_password = h_m.hexdigest()

    try:
        user = User.objects.get(user_id=user_id)
    except Exception as e:
        print('---login error %s' % (e))
        result = {'code': 10200, 'error': '你的工号输入错误'}
        return JsonResponse(result)

    if old_password != user.password:
        result = {'code': 10201, 'error': '你输入的原密码错误'}
        return JsonResponse(result)

    if password_1 != password_2:
        result = {'code': 10201, 'error': '你输入的新密码不一致'}
        return JsonResponse(result)

    h_m = hashlib.md5()
    h_m.update(password_1.encode())
    password = h_m.hexdigest()
    # 数据库密码的更改
    User.objects.filter(user_id=user_id).update(password=password)

    result = {'code': 200, 'page': 'login'}
    return JsonResponse(result)

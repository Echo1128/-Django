from django.db import models

# Create your models here.

class User(models.Model):

    user_id = models.IntegerField(verbose_name='员工工号',primary_key=True)
    user_name = models.CharField(verbose_name='员工姓名',max_length=20)
    password = models.CharField(verbose_name='密码',max_length=40)
    department = models.CharField(verbose_name='部门',max_length=20)
    position = models.CharField(verbose_name='岗位',max_length=20)
    phone = models.CharField(max_length=11,verbose_name='手机号',default='')
    created_time = models.DateTimeField(auto_now_add=True)
    updated_time = models.DateTimeField(auto_now=True)
    
    class Meta:
        db_table = 'user_info'
        verbose_name_plural ='员工花名册'
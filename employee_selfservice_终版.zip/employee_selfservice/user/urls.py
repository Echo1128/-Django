from django.urls import path
from . import views


urlpatterns = [

    #http://127.0.0.1:8000/users/index
    # path('index', views.register_view),
    path('login',views.login_view),#登录页面
    path('login_post',views.login_post),#登录页面提交的数据

    path('register',views.reg_view),#注册页面
    path('reg_post',views.reg_post),#注册页面提交的数据

    path('forget',views.forget_view),#忘记密码页面
    path('phone_post',views.phone_view),#忘记密码手机号码处理
    path('forget_post',views.forget_post),#忘记密码页面提交数据处理函数

    path('home',views.home_page),#主页

    path('change',views.change_view),#修改密码页面
    path('put',views.put_view),#修改密码数据处理页面


]

from django.conf import settings
from django.http import JsonResponse
import jwt
from user.models import User


def loging_check(func):
    def wrap(request,*args,**kwargs):
        # 请求头 - Authorization
        token = request.META.get('HTTP_AUTHORIZATION')

        if not token:
            result = {'code': 403, 'error': 'Please login'}
            return JsonResponse(result)
        # 校验token
        try:
            # header {'alg':'HS256'}
            res = jwt.decode(token, settings.JWT_TOKEN_KEY)
        except Exception as e:
            result = {'code': 403, 'error': 'Please login'}
            return JsonResponse(result)
        employee_id=res['user_id']
        employee=User.objects.filter(user_id=employee_id)
        request.employee_slef=employee
        return func(request, *args, **kwargs)
    return wrap
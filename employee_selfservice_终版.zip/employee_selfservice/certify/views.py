 #!/usr/bin/env Python
# coding=utf-8


from django.http import HttpResponse, JsonResponse
from django.shortcuts import render

from user.models import User
from . models import *
import json
# Create your views here.


def shenqing_page(request):


    return render(request,'shenqing.html')



def xiangqing_page(request):

    return render(request,'chaxun.html')

# def test_xhr(request):
#
#
#     return HttpResponse('this is xhr')
#
# def test_jq_get(request):
#
#     return render(request,'zmkj/test_jq_get.html')
#
# def test_jq_get_server(request):
#
#     # return render(request,'zmkj/test_jq_get_server.html')
#       return HttpResponse('this is jq ajax!!!')
def post_db(request):
    json_str = request.body
    json_obj = json.loads(json_str)
    userid = json_obj['userid']
    username = json_obj['username']
    dep = json_obj['dep']
    station = json_obj['station']
    reason = json_obj['reason']
    model = json_obj['model']
    # file=json_obj['file']
    users=User.objects.filter(user_id=userid)
    a=[]
    b=[]
    for user in users:

        a.append(user)
    print("哈哈")
    if a==b :
        user1=User.objects.create(user_id=userid,user_name=username,department=dep,position=station)
        ApplyCertify.objects.create(ask_reason=reason,certify_type=model,apply_status=1,apply_id=user1)
        # ZMJL.objects.create(AR=reason,category=model,ID_file=file)
    else:
        ApplyCertify.objects.create(ask_reason=reason,certify_type=model,apply_status=1,apply_id=a[0])
    date={"date":"证明开具资料已提交","a":username,"b":userid}

    return JsonResponse(date)

def post_file(request):

    # userid=request.POST.get('userid')
    file = request.FILES['file']
    # user1 = User.objects.get(userid=userid)
    print("试一下")
    zmjl1=ApplyCertify.objects.order_by('flowid').last()
    print(zmjl1.flowid)
    print("这里代表成功")
    zmjl1.document=file
    # zmjl1.AR="haha"
    zmjl1.save()

    date = {"date":"证明开具资料已上传"}
    return JsonResponse(date)
    # return HttpResponse('HAHA')
def post_chaxun_page(request,userid):
    user1 = User.objects.get(user_id=userid)
    user_id=user1.user_id
    username=user1.user_name
    dept=user1.department
    station=user1.position

    zmjls = ApplyCertify.objects.filter(apply_id=user_id)
    list_obj=[]
    for zmjl in zmjls:
        dic={}

        b=zmjl.flowid
        d=zmjl.certify_type
        f=zmjl.apply_time
        h=zmjl.ask_reason
        j=zmjl.apply_status

        if j==1:
            i="已提交"
        else:
            i="审核完成"
        dic={"user_id":user_id,"username":username,"dept":dept,"station":station,"flowid":b,'certify_type':d,"apply_time":f,'ask_reason':h,'apply_status':i}
        list_obj.append(dic)

    data={'data':list_obj}

    return JsonResponse(data)

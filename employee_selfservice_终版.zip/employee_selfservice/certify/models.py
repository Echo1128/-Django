from django.db import models
apply_choices=(
        (1, "提交"),
        (2, "撤回")
)

# Create your models here.
from user.models import User
class ApplyCertify(models.Model):
        flowid=models.AutoField(verbose_name='流程单号',primary_key=True)
        ask_reason=models.CharField(verbose_name='申请原因',max_length=300)
        certify_type=models.CharField(verbose_name='证明类别',max_length=20)
        document=models.ImageField(verbose_name='证明文件')
        apply_time=models.DateTimeField(verbose_name='提交时间',auto_now_add=True)
        # recall_time=models.DateTimeField(verbose_name='撤回时间',auto_now_add=True)
        # finish_time=models.DateTimeField(verbose_name='审核完成时间',auto_now_add=True)
        # comment=models.CharField(verbose_name='审核意见',max_length=300)
        apply_status=models.SmallIntegerField(verbose_name="申请状态",choices=apply_choices)
        apply_id=models.ForeignKey(User,on_delete=models.CASCADE,verbose_name='员工工号')

        class Meta:
                db_table = 'apply_certify'
                verbose_name_plural = '证明开具表'
from django.urls import path

from . import views

urlpatterns = [
     path('applycertify',views.shenqing_page),
     path('asks',views.xiangqing_page),
     path('post_db',views.post_db),
     path('post_file',views.post_file),
     path('post_chaxun_page<int:userid>',views.post_chaxun_page)

]

from django.apps import AppConfig


class CertifyConfig(AppConfig):
    name = 'certify'

from django.http import HttpResponse, JsonResponse
import json
import  datetime

from django.shortcuts import render

from .models import *
from tool.logging_dec import loging_check


# Create your views here.

#10100 - 10199 异常码
def get_html(request):
    return render(request,'askleave.html')
def get_askleaveinfo(request):
    # 后端路由能够走通
    # ajax也能成功发送
    print('进入提交页面啦')
    json_str=request.body
    json_obj=json.loads(json_str)
    user_id=json_obj['user_id']
    leave_type=json_obj['leave_type']
    leave_times=json_obj['leave_times']
    leave_start_time=datetime.datetime.strptime(json_obj['leave_start_time'],"%Y-%m-%d").date()
    leave_end_time=datetime.datetime.strptime(json_obj['leave_end_time'],"%Y-%m-%d").date()
    print("输出结束时间=============")
    print(leave_end_time)
    leave_reason=json_obj['leave_reason']

    try:
        print('开始写入请假信息')
        user=User.objects.get(user_id=user_id)

        ApplyLeave_obj=ApplyLeave.objects.create(apply_id=user,user_name=user.user_name,leave_type=1,apply_status=1,leave_times=leave_times,leave_start_time=leave_start_time,leave_end_time=leave_end_time,apply_reason=leave_reason)

        result={'code':200,'askleaveid':ApplyLeave_obj.flowid}
        return JsonResponse(result)
    except Exception as e:
        print('提交入数据库失败')
        result = {'code': 201}
        return JsonResponse(result)
def upload_file(request):
    # 访问路径：/user/qs/?a=1&b=2&a=3
    # 注意：查询字符串不区分请求方式，客户端GET，POST方式的请求，都可以通过request.GET获取请求中的查询字符串数据。

    askleaveid=request.GET.get('askleaveid')
    # 此时传过来的flowid_id为str类型
    allpyleave_obj = ApplyLeave.objects.get(flowid=askleaveid)
    # 测试上传附件
    file_obj = request.FILES['file']
    name = file_obj.name
    try:

        allpyleave_obj.document=file_obj
        allpyleave_obj.save()
        # test_file.objects.create(name=name,myfile=file_obj)
        print('这代表上传成功哈:' + name)
        result={'code':200}
        return JsonResponse(result)
    except Exception as e:
        print('文件写入数据库失败')
        result = {'code': 201}
        return JsonResponse(result)
def get_in(requset):
    return render (requset,'record.html')

def record_view(request):
    print('--view in')
    json_str=request.body
    json_obj=json.loads(json_str)
    user_id=json_obj['userid']
    # user_id=User.objects.get(userid=userid)
    apply_set=ApplyLeave.objects.filter(apply_id=user_id)
    data=[]
    for app in apply_set:
        flowid=app.flowid
        user_name=app.user_name
        leave_type=app.leave_type
        apply_status=app.apply_status
        apply_time=app.apply_time
        leave_start_time=app.leave_start_time
        leave_end_time=app.leave_end_time   
        dict={"flowid":flowid,"user_name":user_name,"user_id":user_id,"leave_type":leave_type,
        "apply_time":apply_time,"leave_start_time":leave_start_time,"leave_end_time":leave_end_time,
        "apply_status":apply_status}
        data.append(dict)
    print(data)
    result={'code':200,'data':data}
    return JsonResponse(result)


    # print(userid)

    return JsonResponse({'code':200})

def get_employee_tafv(employee_id):
    #employee_id=request.employee_id
    adminer=LeaveApproveSick.objects.filter(apply_id=employee_id,status=2)
    employee=LeaveResultSick.objects.filter(apply_id=employee_id)
    employee.total_days_sick=sum(adminer.apply_day)
    count=employee.total_days_sick
    employee.left_days_sick=int(10-count)
    return (employee.total_days_sick,employee.left_days_sick)


def get_employee_even(employee_id):
    adminer = LeaveApprovePer.objects.filter(apply_id=employee_id,status=2)
    employee = LeaveResultPer.objects.filter(apply_id=employee_id)
    employee.total_days_per=sum(adminer.apply_day)
    return employee.total_days_per

def get_employee_holiday(employee_id):
    adminer = LeaveApproveAnn.objects.filter(apply_id=employee_id,status=2)
    employee = LeaveResultAnn.objects.filter(apply_id=employee_id)
    employee.total_days_ann=sum(adminer.apply_day)
    count=employee.total_days_ann
    employee.left_days_ann=int(15-count)
    return (employee.total_days_ann,employee.left_days_ann)

@loging_check
def post_employee_tafv(request):
    employee_id=request.employee_slef.user_id
    employee_name=request.employee_slef.user_name
    employee_department=request.employee_slef.department
    jon_str=json.dumps(request.body)
    data=json.loads(jon_str)
    apply_reason=data.get('apply_reason')
    apply_day=data.get('apply_day')
    LeaveApproveSick.objects.create(user_name=employee_name,
                                 apply_id=employee_id,department=employee_department,
                                apply_reason=apply_reason,apply_day=apply_day
                                 )
    return {'code':200,'data':'病假申请发送成功'}

@loging_check
def post_employee_event(request):
    employee_id = request.employee_slef.user_id
    employee_name = request.employee_slef.user_name
    employee_department = request.employee_slef.department
    jon_str = json.dumps(request.body)
    data = json.loads(jon_str)
    apply_reason = data.get('apply_reason')
    apply_day = data.get('apply_day')
    LeaveApprovePer.objects.create(user_name=employee_name,
                                 apply_id=employee_id,department=employee_department,
                                apply_reason=apply_reason,apply_day=apply_day
                                 )
    return {'code':200,'data':'事假申请发送成功'}

@loging_check
def post_employee_holiday(request):
    employee_id = request.employee_slef.user_id
    employee_name = request.employee_slef.user_name
    employee_department = request.employee_slef.department
    jon_str = json.dumps(request.body)
    data = json.loads(jon_str)
    apply_reason = data.get('apply_reason')
    apply_day = data.get('apply_day')
    LeaveApproveAnn.objects.create(user_name=employee_name,
                                 apply_id=employee_id,department=employee_department,
                                apply_reason=apply_reason,apply_day=apply_day
                                 )
    return {'code':200,'data':'年假申请发送成功'}

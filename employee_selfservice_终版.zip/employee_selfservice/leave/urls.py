from django.urls import path
from . import views


urlpatterns = [

    #http://127.0.0.1:8000/leave/record
    path('find',views.get_in),
    path('get_record_html', views.get_in),
    path('record',views.record_view),
    path('sickleave',views.get_html),
    path('askleaveinfo', views.get_askleaveinfo),
    path('upload',views.upload_file),
]
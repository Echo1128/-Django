from django.db import models
from user.models import User
# from admin_manager.models import Approver
# Create your models here.

leave_choices = (
        (1, "病假"),
        (2, "事假"),
        (3, "年假"))
apply_choices=(
        (1, "提交"),
        (2, "撤回")
)
approve_choices=(
        (1,"待审核"),
        (2,"同意"),
        (3,"拒绝")
)

class ApplyLeave(models.Model):
    flowid=models.AutoField(primary_key=True,verbose_name="流程单号")
    apply_id = models.ForeignKey(User, on_delete=models.CASCADE,verbose_name='员工工号')
    user_name = models.CharField(verbose_name='员工姓名',max_length=20)
    leave_type=models.SmallIntegerField(verbose_name="假别",choices=leave_choices)
    apply_status=models.SmallIntegerField(verbose_name="申请状态",choices=apply_choices)
    leave_times=models.IntegerField(verbose_name='请假时长',default=0)
    apply_time=models.DateTimeField(auto_now_add=True,verbose_name='提交时间')
    leave_start_time=models.DateField(verbose_name='请假开始时间')
    leave_end_time=models.DateField(verbose_name='请假结束时间')
    apply_reason = models.TextField(max_length=50, verbose_name='请假原因')
    document=models.FileField(verbose_name='文件',upload_to='', null=True,default='')

    class Meta:
        db_table = 'apply_leave'
        verbose_name_plural = '请假申请表'

class LeaveApproveSick(models.Model):
    approver_id = models.IntegerField(verbose_name='审核人工号', primary_key=True)
    approver_name = models.CharField(max_length=20, verbose_name='审核人姓名')
    
    apply_id = models.ForeignKey(User, on_delete=models.CASCADE,verbose_name='员工工号')
    user_name = models.CharField(verbose_name='员工姓名',max_length=20)
    department = models.CharField(max_length=20, verbose_name='部门')
    apply_reason = models.CharField(max_length=11, verbose_name='请假原因')
    apply_day = models.IntegerField(verbose_name='请假时长',default=0)
    approve_status = models.SmallIntegerField(verbose_name='审核状态', choices=approve_choices)
    comment = models.TextField(max_length=50, verbose_name='审核原因')
    created_time = models.DateTimeField(auto_now_add=True)
    updated_time = models.DateTimeField(auto_now=True)


    class Meta:
        db_table = 'leave_approve_sick'
        verbose_name_plural = '病假审核表'

class LeaveApprovePer(models.Model):
    approver_id = models.IntegerField(verbose_name='审核人工号', primary_key=True)
    approver_name = models.CharField(max_length=20, verbose_name='审核人姓名')
    apply_id = models.ForeignKey(User, on_delete=models.CASCADE,verbose_name='员工工号')
    user_name = models.CharField(verbose_name='员工姓名',max_length=20)
    department = models.CharField(max_length=20, verbose_name='部门')
    apply_reason = models.CharField(max_length=11, verbose_name='请假原因')
    apply_day = models.IntegerField(verbose_name='请假时长')
    approve_status = models.SmallIntegerField(verbose_name='审核状态', choices=approve_choices)
    comment = models.TextField(max_length=50, verbose_name='审核原因')
    created_time = models.DateTimeField(auto_now_add=True)
    updated_time = models.DateTimeField(auto_now=True)


    class Meta:
        db_table = 'leave_approve_per'
        verbose_name_plural = '事假审核表'

class LeaveApproveAnn(models.Model):
    approver_id = models.IntegerField(verbose_name='审核人工号', primary_key=True)
    approver_name = models.CharField(max_length=20, verbose_name='审核人姓名')
    apply_id = models.ForeignKey(User, on_delete=models.CASCADE,verbose_name='员工工号')
    user_name = models.CharField(verbose_name='员工姓名',max_length=20)
    department = models.CharField(max_length=20, verbose_name='部门')
    apply_reason = models.CharField(max_length=11, verbose_name='请假原因')
    apply_day = models.IntegerField(verbose_name='请假时长',default=0)
    approve_status = models.SmallIntegerField(verbose_name='审核状态', choices=approve_choices)
    comment = models.TextField(max_length=50, verbose_name='审核原因')
    created_time = models.DateTimeField(auto_now_add=True)
    updated_time = models.DateTimeField(auto_now=True)


    class Meta:
        db_table = 'leave_approve_ann'
        verbose_name_plural = '年假审核表'

class LeaveResultSick(models.Model):
    apply_id = models.ForeignKey(User, on_delete=models.CASCADE,verbose_name='员工工号')
    user_name = models.CharField(verbose_name='员工姓名',max_length=20)
    department = models.CharField(max_length=20, verbose_name='部门')
    total_days_sick=models.IntegerField(verbose_name='总请病假时长',default=0)
    left_days_sick=models.IntegerField(verbose_name='剩余病假时长',default=0)
    created_time = models.DateTimeField(auto_now_add=True)
    updated_time = models.DateTimeField(auto_now=True)
    class Meta:
        db_table = 'leave_result_sick'
        verbose_name_plural = '病假结果表'

class LeaveResultPer(models.Model):
    apply_id = models.ForeignKey(User, on_delete=models.CASCADE,verbose_name='员工工号')
    user_name = models.CharField(verbose_name='员工姓名',max_length=20)
    department = models.CharField(max_length=20, verbose_name='部门')
    total_days_per=models.IntegerField(verbose_name='总请事假时长',default=0)
    created_time = models.DateTimeField(auto_now_add=True)
    updated_time = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'leave_result_per'
        verbose_name_plural = '事假结果表'

class LeaveResultAnn(models.Model):
    apply_id = models.ForeignKey(User, on_delete=models.CASCADE,verbose_name='员工工号')
    user_name = models.CharField(verbose_name='员工姓名',max_length=20)
    department = models.CharField(max_length=20, verbose_name='部门')
    total_days_ann=models.IntegerField(verbose_name='总请年假时长',default=0)
    left_days_ann=models.IntegerField(verbose_name='剩余年假时长',default=0)
    created_time = models.DateTimeField(auto_now_add=True)
    updated_time = models.DateTimeField(auto_now=True)
    class Meta:
        db_table = 'leave_result_ann'
        verbose_name_plural = '年假结果表'


    

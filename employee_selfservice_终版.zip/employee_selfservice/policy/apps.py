from django.apps import AppConfig


class PolicyConfig(AppConfig):
    name = 'policy'

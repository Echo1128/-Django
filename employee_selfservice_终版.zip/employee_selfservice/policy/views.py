from django.shortcuts import render

# Create your views here.

def index_view(request):

    return render(request, 'Home_policy.html')

def detail1_view(request):

    return render(request, 'Detail_pay.html')

# def detail2_view(request):
#
#     return render(request, 'Detail_pay2.html')

def detail3_view(request):

    return render(request, 'Detail_event.html')
